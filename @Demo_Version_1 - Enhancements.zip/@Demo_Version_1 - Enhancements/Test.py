# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 13:50:46 2020

@author: gjangili
"""

import pandas as pd

df = pd.read_csv("AE.csv")
List = df.columns
print(List)
#OS
import os
#Doc
from docx import Document
#Pandas
import pandas as pd
#Flask API
from flask import Flask, render_template, request, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename
import json

#Only csv files are allowed
ALLOWED_EXTENSIONS = {'csv'}
File_Name = {'Template'}
app = Flask(__name__)
#Give always a new file for export (as we are using send_file)
app.config['SEND_FILE_MAX_AGE_DEFAULT']=0 
#Size 16MB
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
#Cache control
CORS(app) 
app.config['TEMPLATES_AUTO_RELOAD'] = True
@app.after_request
def add_header(response):
    # response.cache_control.no_store = True
    if 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'no-store'
    return response

#Current Directory
curr_path = os.getcwd()

def process_csr(csr_file,template_file):
    #Create Empty Doc
    if os.path.exists(curr_path+"\AE_Out.docx"):
        os.remove(curr_path+"\AE_Out.docx")
        
    document = Document()
    #Templates for strings
    Strings_df = pd.read_csv(template_file)
    #Strings_df = pd.DataFrame(b)
    string = [None]*10
    
    for ind in Strings_df.index:
        string[ind] = Strings_df.loc[ind,'String_Name']
    
    #Empty Strings
    string1 = ""
    string2 = ""
    string3 = ""
    string4 = ""
    a = 0
    
    #Read csr input    
    df = pd.read_csv(csr_file)
    #df = pd.DataFrame(csr)
    for ind in df.index:
            #Read colummns here
                a = a+1
                col1 = df.loc[ind,'no_of_patients']
                col2 = df.loc[ind,'patients_w_gr_3_teae']
                col3 = df.loc[ind,'percent_w_gr_3_teae']
                col4 = df.loc[ind,'patients_w_serious_teae']
                col5 = df.loc[ind,'percent_w_serious_teae']
                col6 = df.loc[ind,'patients_w_teae_death']
                col7 = df.loc[ind,'percent_w_teae_death']
                col8 = df.loc[ind,'patients_w_teae_perm_treat_discontinue']
                col9 = df.loc[ind,'percent_w_teae_perm_treat_discontinue']
                col10 = df.loc[ind,'patients_w_teae_pre_treat_discontinue']
                col11 = df.loc[ind,'percent_w_teae_pre_treat_discontinue']
        
                if df.loc[ind,'no_of_patients'] == df.loc[ind,'patients_w_teae']:
                    string1 = string[0].format(col1 = col1)
                else:
                    string1 = string[1].format(col1 = col1)
        
                if df.loc[ind,'patients_w_gr_3_teae'] > 0 :
                    string2 =  string[2].format(col2 = col2,col3 = col3)
                else:
                    string2 =  string[3]
                             
                if df.loc[ind,'patients_w_serious_teae'] > 0 & df.loc[ind,'patients_w_teae_death'] >0:
                    string3 =  string[4].format(col4 = col4,col5 = col5,col6 = col6,col7 = col7)
                else:
                    string3 =  string[5].format(col4 = col4,col5 = col5)
                
                if df.loc[ind,'patients_w_teae_perm_treat_discontinue'] > 0 & df.loc[ind,'patients_w_teae_pre_treat_discontinue'] >0:
                       string4 = string[6].format(col8 = col8,col9 = col9,col10 = col10,col11 = col11)
                elif df.loc[ind,'patients_w_teae_perm_treat_discontinue'] == 0 & df.loc[ind,'patients_w_teae_pre_treat_discontinue'] == 0:
                       string4 = string[7]
                elif df.loc[ind,'patients_w_teae_perm_treat_discontinue'] == 0 & df.loc[ind,'patients_w_teae_pre_treat_discontinue'] > 0:
                       string4= string[8].format(col6 = col6,col7 = col7)
                elif df.loc[ind,'patients_w_teae_perm_treat_discontinue'] > 0 & df.loc[ind,'patients_w_teae_pre_treat_discontinue'] == 0:
                       string4= string[9].format(col8 = col8,col9 = col9)
                
                # Add paragraph in word file
                document.add_paragraph(str(a)+'. ' +string1+string2+string3+string4) 
    document.save(curr_path+"\AE_Out.docx")

@app.route('/')
def html_file():
   return render_template('Lat.html')
	
@app.route('/', methods = ['POST'])
def upload_file():
   if request.method == 'POST':
      #f = request.files['file'] 
      uploaded_files = request.files
      uploaded_files = uploaded_files.to_dict(flat=False)
      files = uploaded_files["file"]
      filenames = []
      for file in files:
          if (file.filename).split(".")[1] in ALLOWED_EXTENSIONS:
              file.save(secure_filename(file.filename))
              filenames.append(file.filename)
          else:
              return 'file format is not supported'
      Dict = {"CSR":filenames[0],"Template":filenames[1]}  
      with open('f.json',"w") as A:
          json.dump(Dict,A)
      #upload template and source file columns
      input_file  = pd.read_csv(filenames[0])
      col_list = input_file.columns
      df = pd.read_csv(filenames[1])
      items = df.to_dict('records')
      return render_template("Lat.html",items=items,columns=col_list)
      
  
 
@app.route('/')  
def upload(template_file):  
      df = pd.read_csv(template_file)
      items = df.to_dict('records')
      return render_template("Lat.html",items=items) 

@app.route('/Update', methods=['POST'])
def update_file():
    if request.method == 'POST':
      req = request.get_json()
      df=pd.DataFrame(req)
      df.columns = ["Sno","String_Name"]
      with open('f.json',"r") as A:
            Dict = json.load(A)
      df.to_csv(Dict["Template"],index=False)
      return 'success'
  
@app.route('/output',methods = ['GET', 'POST'])
def download_file():
    if request.method == 'GET':
        with open('f.json',"r") as A:
            Dict = json.load(A)
            process_csr(Dict["CSR"],Dict["Template"])
        return send_file(curr_path+"\AE_Out.docx")
          
  
if __name__ == '__main__':
   app.run(debug = True)
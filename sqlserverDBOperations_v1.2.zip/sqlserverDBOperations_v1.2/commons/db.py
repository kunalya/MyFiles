import pandas as pd,time,numpy as np,math
from tqdm import tqdm
def connections(environment):
 import pypyodbc,json

 with open('connections.properties') as f:
  vals=json.load(f)[environment]
  auto_commit=True
  connection = pypyodbc.connect("Driver={SQL Server};"+f"Server={vals['server']};Database={vals['database']};trusted_connection='yes';")
  cursor = connection.cursor()
  connection.commit()
  return cursor,connection


def sql_table(table,cursor,*args,**kwargs):
    batchsize=300000
    total=math.ceil(cursor.execute(f'select count(*) from {table}').fetchall()[0][0]/batchsize)
    lower = kwargs.get('lower',True)
    c=kwargs.get('columns',None)
    query=kwargs.get('query',None)
    if c is not None:
      r=f'{",".join([x for x in c])} from {table}'
    else:
        r=f' * from {table}'
   
    if query is not None:
        r=r+f" where {query}"
  
    d=kwargs.get('top',None)
    if d is not None:
        total=math.ceil(d/batchsize)
        cursor.execute(f"select top {d}  "+r)
    else:
        total=math.ceil(cursor.execute(f'select count(*) from {table}').fetchall()[0][0]/batchsize)
        cursor.execute(f"select " +r)

    


    cols=[x[0] for x in cursor.description]


    pbar=tqdm(total=total)
    df=pd.DataFrame()
    while True:
      a=cursor.fetchmany(batchsize)

      if  len(a)!=0:

        df=df.append(a)
        pbar.update(1)

      else:

        break
    pbar.close()
    if len(df)!=0:
     df.columns=cols
    else:
        df=pd.DataFrame(columns=cols)
    df=df.reset_index(drop=True)

    

    df=df.drop_duplicates()

    def f(i):
     cursor.execute(f"SELECT {i} FROM {table} WHERE {i} LIKE REPLACE('00000000-0000-0000-0000-000000000000', '0', '[0-9a-fA-F]')")
     f=cursor.fetchone()

     if f is not None:

      return i





   # l=[i for i in cols  if f(i) is not None ]

    #if len(l)!=0:

    # df=pd.DataFrame([df[f(i)].str.lstrip('b').str.strip("'")  if f(i) is not None else df[i] for i in cols]).T
    if lower:
        df.columns = [x.lower() for x in df.columns]
    df=df.replace(np.nan,'',regex=True)
    return df






def db_types(table,cursor):

    cursor.execute(f'select * from {table}')
    cols=[x[0] for x in cursor.description]

    cursor.execute("select "+ ','.join([f"columnproperty(object_id('{table}'),'{x}','isidentity') as {x}" for x in cols]))

    df=pd.DataFrame(cursor.fetchall())


    df.columns=cols
    df=df.T.reset_index()
    df.columns=['cols','value']
    identity=df.loc[df['value']==0,'cols'].tolist()

    cursor.execute(f"select column_name,data_type from INFORMATION_SCHEMA.columns  where table_name='{table.split('.')[1].strip('[').strip(']').strip()}' and table_schema='{table.split('.')[0].strip('[').strip(']').strip()}'")
    df=pd.DataFrame(cursor.fetchall()).apply(lambda x:x.astype(str).str.lower())
    df.columns=[x[0] for x in cursor.description]

    return df,identity



def drop_table(table,cursor,connection):
    cursor.execute(f'drop table {table}')
    connection.commit()


def delete_data(table,cursor,connection,*args,**kwargs):
    query=kwargs.get('query',None)
    if query is not None:

     cursor.execute(f"delete from  {table} where {query}")
     connection.commit()
    else:
        cursor.execute(f"delete from  {table}")
        connection.commit()

def insert(table,df,cursor,connection) :

    cols=db_types(table,cursor)[0].column_name.tolist()
    columns=df.columns.tolist()
    cols=list(set(cols).intersection(set(columns)))

    df=df[cols]
    df=df.drop_duplicates()

    if len(df)!=0:
     cursor.execute(f"insert into {table} ({','.join([x for x in cols])}) values {','.join([str(x) for x in [tuple(r) for r in [*map(list,zip(*map(df.get,df)))]]])}")

     connection.commit()


def insert_data(table,position,cursor,connection) :


 r=db_types(table,cursor)[0]
 r1=pd.DataFrame(position.dtypes).reset_index()
 r1.columns=['column_name','dtype']
 r=pd.merge(r,r1,how='inner').astype(str)
 r['data_type']=r['data_type'].replace('nvarchar','object')
 r['data_type']=r['data_type'].replace('int','int64')
 r['flag']=np.where(r['data_type']==r['dtype'],True,False)

 cols=r.loc[(r['flag']==False) &(r['dtype']=='float64')].column_name.tolist()
 for i in cols:

  try:
   position[i]= position[i].astype('Int64')
  except:
     position[i]= position[i].astype('Float64')



#asset['parentassetguid']=asset.apply(lambda x:uuid.uuid4(),axis=1).astype(str)
#asset['assettypeguid']=asset.apply(lambda x:uuid.uuid4(),axis=1).astype(str)



 position=position.replace(np.nan,'',regex=True)

 for i in cols:
  position[i]= position[i].astype(str)

 cols=r.loc[(r['dtype']=='object')&(r['data_type'].isin(['int64','float']))].column_name.tolist()
 for i in cols:
  position[i]= position[i].astype(str)


 cols=r.loc[r['data_type']=='bit','column_name'].tolist()
 for i in cols:
     position.loc[position[i]=='',i]=0

     position[i]= position[i]*1

 cols=r.loc[(r['flag']==False) &(r['dtype'].isin(['object','datetime64[ns]']))&(r['data_type'].str.contains('datetime'))].column_name.tolist()

 for i in  cols:
  if set(position[i].drop_duplicates())=={''}:
      position=position.drop(columns=[i])
      cols.remove(i)
  else:
   try:
    position[i]=position.apply(lambda x:pd.to_datetime(x[i]).strftime("%Y-%m-%d %H:%M:%S") if x[i]!='' else '' ,axis=1)
   except:
        position[i]=''


 def f(x,cols):
  l=[i for i in cols if x[i]=='']
  return str(l),len(l)




 position['flag'],position['count']=zip(*position.apply(lambda x:f(x,cols),axis=1) )


 master_list=position[['flag','count']].drop_duplicates()
 master_list=master_list.sort_values('count',ascending=False)
 master_list=master_list.reset_index(drop=True)


 import ast
 for index,row in master_list.iterrows():

    flag=ast.literal_eval(row.flag)
    dfx=position
    for i in flag:
        dfx=dfx.loc[dfx[i]=='']
    dfx=dfx.drop(columns=flag)
    insert(table,dfx,cursor,connection)
    position=position.loc[position['flag']!=row.flag]









 if len(position)!=0:
  insert(table,position,cursor,connection)



def db_primaryKey(query,cursor):

    #cursor.execute(f"SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS TC INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KU ON TC.CONSTRAINT_TYPE = 'PRIMARY KEY' AND TC.CONSTRAINT_NAME = KU.CONSTRAINT_NAME AND  KU.table_name={table} AND KU.TABLE_SCHEMA={schema} ORDER BY KU.TABLE_NAME, KU.ORDINAL_POSITION;")
    #cursor.execute(f'SELECT KU.table_name as TABLENAME,column_name as PRIMARYKEYCOLUMN FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS TC INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KU ON TC.CONSTRAINT_TYPE = 'PRIMARY KEY' AND TC.CONSTRAINT_NAME = KU.CONSTRAINT_NAME AND  KU.table_name={table} AND KU.TABLE_SCHEMA={schema} ORDER BY KU.TABLE_NAME, KU.ORDINAL_POSITION')
    cursor.execute(query)

    df=pd.DataFrame(cursor.fetchall())

    return df




# -*- coding: utf-8 -*-
"""
Created on Wed Apr  8 20:41:03 2020

@author: nimondal
"""
import logging

# Gets or creates a logger
logger = logging.getLogger(__name__)  

# set log level
logger.setLevel(logging.INFO)

# define file handler and set formatter
file_handler = logging.FileHandler('app.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)

# add file handler to logger
logger.addHandler(file_handler)

# Logs
#logger.debug('A debug message')
#logger.info('An info message')
#logger.warning('Something is not right.')
#logger.error('A Major error has happened.')
#logger.critical('Fatal error. Cannot continue')





import pandas as pd,numpy as np
from pandasql import sqldf  
pysqldf=lambda q:sqldf(q,globals())
import os
from datetime import date

def compare_dataframes(df1,df2):
   
    df= pd.concat([df1,df2]).drop_duplicates(keep=False)
    return df

def compare_dataframesMinusQuery(df1,df2):
   
    q="select * from df1 except select * from df2"
    df=sqldf(q, locals())
    return df

def colValueTransformLogic1(dfIn,colIn,ColOut):
   
    dfIn[ColOut]=dfIn[colIn]*12
    df=dfIn.drop(columns=[colIn])
    return df

def storeTheDifference(df,filename):
    
    os.chdir('....')
    #os.chdir('.\\OutputResults')
    directory = '.\\OutputResults'
    os.path.join(directory)
    print(os.path.join(directory))
    df.to_excel(os.path.join(directory, filename))
    print('Diferrences are stored in OutputResults Folder')
    return None

def dataCompleteness_CountAndColumnDataProfile(df1,df2,col):
    
    print('The number max value of given column of the tables/dataframes are',df1[col].max(),'and',df2[col].max())
    print('The number Min value of given column of the tables/dataframes are',df1[col].min(),'and',df2[col].min())
    print('The number Sum of the given column of the tables/dataframes are',df1[col].sum(),'and',df2[col].sum())
    print('The number of rows of the table/df are',len(df1),'and',len(df2))
    print('The number of null values on the table/df are',df1[col].isna().sum(),'and',df2[col].isna().sum())
    a=df1[col].max()-df2[col].max()
    b=df1[col].min()-df2[col].min()
    c=df1[col].sum()-df2[col].sum()
    d=len(df1)-len(df2)
    e=df1[col].isna().sum()-df2[col].isna().sum()
    if a==0 and b==0 and c==0 and d==0 and e==0:
        print('The DATA COMPLETENESS testing status-Pass: Both source and target matched')
        return True
    else:
        print('The DATA COMPLETENESS testing status-Fail: source and target not matched')
        return False



def colValueTransformLogic2(df,col):
   
    def f(x):   
      x=x[0:10]
      return x
    df[col]=df.apply(lambda x: f(x.col),axis=1)
    return df

def transformIntoDateFromDaytime2Type(x):   
   x=x[0:10]
   logger.info('The time span on date is truncated')
   return x    


def changeDateFormatInDaytime(df,col,inputformat):
   logger.info(f'{col} Column is passed on changeDateTimeFormat with {inputformat} format')
   df[col] = pd.to_datetime(df[col],format=inputformat)
   return df

def applyDateRangeFilterOnDayTime(df,col,year1,month1,day1,year2,month2,day2):
   logger.info(f'{col} Column is passed on to apply date filter from {year1}/{month1}/{day1} to {year2}/{month2}/{day2}')
   date_from = pd.Timestamp(date(year1,month1,day1))
   date_to = pd.Timestamp(date(year2,month2,day2))
   logger.info(f' from date is {date_from} and to date is {date_to}')
   df = df[
    (df[col] > date_from ) &
    (df[col] < date_to)]
   return df




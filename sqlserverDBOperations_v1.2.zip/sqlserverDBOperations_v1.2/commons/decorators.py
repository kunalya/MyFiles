import time
def timeit(function):
    def wrapper():
        start=time.time()
        func = function()
        
        duration = time.time()-start
        return duration

    return wrapper



def delay(timeout):
 def extra(function):
    def wrapper1():
        time.sleep(timeout)
        func = function()
        

    return wrapper1
 return extra





from commons.db import *
from commons.dfOperations import *

from datetime import datetime





##connect to db using environment name

cursor,connection=connections('source')
logger.info('DB connection successfull')
##############


##read all columns from table

query = "SELECT * FROM [Sales].[Orders];"

dfSalesData = pd.read_sql(query, connection)



##Get the primary key of the table by passing query

queryPK="SELECT KU.table_name as TABLENAME,column_name as PRIMARYKEYCOLUMN FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS TC INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KU ON TC.CONSTRAINT_TYPE = 'PRIMARY KEY' AND TC.CONSTRAINT_NAME = KU.CONSTRAINT_NAME AND  KU.table_name='orders' AND KU.TABLE_SCHEMA='Sales' ORDER BY KU.TABLE_NAME, KU.ORDINAL_POSITION;"

dfPK=db_primaryKey(queryPK,cursor)
#dfPK=db_primaryKey('orders',cursor,'Sales')



##read selected columns from table
dfCityCol=sql_table('[Application].[Cities_Archive]',cursor,columns=['CityID','CityName','StateProvinceID','LatestRecordedPopulation','ValidFrom'])


dfCityCol['validfrom']=dfCityCol.apply(lambda x: transformIntoDateFromDaytime2Type(x.validfrom),axis=1)



dfSalesCol=sql_table('[Sales].[Orders]',cursor,columns=['OrderID','CustomerID','SalespersonPersonID','OrderDate','BackorderOrderID','PickingCompletedWhen','LastEditedBy','LastEditedWhen'])
df=dfSalesCol.head(100)
df['pickingcompletedwhen']=df.apply(lambda x: transformIntoDateFromDaytime2Type(x.pickingcompletedwhen),axis=1)


##Properties  or data types of the columns of a table

dfCityColumnType,L1=db_types('[Application].[Cities_Archive]',cursor)
dfSalesColumnType,L1=db_types('[Sales].[Orders]',cursor)

data = [['tom', '20/11/1998'], ['nick', '01/02/2006'], ['juli', '02/12/1980']] 
data = [['tom', '20-11-1998'], ['nick', '01-02-2006'], ['juli', '02-12-1980']] 
df = pd.DataFrame(data, columns = ['Name', 'DOB']) 





df=changeDateFormatInDaytime(df,'DOB','%d-%m-%Y')
dfF=applyDateRangeFilterOnDayTime(df,'DOB',1999,1,1,2010,1,1)